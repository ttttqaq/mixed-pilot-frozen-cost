# Pass rate: 62.43% (108/173)

# Total known cost: 20.009609 CNY

- Total tasks: 100
- Jobs: planned=None, started=174, unstarted=None
- Costs by currency (never summed across currencies): {'CNY': 20.009609400000024}
- Agent: 20.009609; evaluator: 0.000000
- Unscored trajectories: 1
- Superseded nodes (retained, excluded from pass rate): 0
- Cost complete: False
- Stop: budget_exhausted

passed / scored leaf trajectories; KSR leaves are correlated, not independent task trials

Incomplete/error trajectories retain null labels. EmptyResponseLimit counts as failure.
Shared prefixes appear in multiple traces; total cost counts each API call once.

## Costs by profile (known amounts)

| Profile | Currency | Agent | Evaluator | Total | Complete | Uncertain calls |
| --- | --- | ---: | ---: | ---: | --- | ---: |
| qwen-flash-2025-07-28 | CNY | 0.631877 | 0.000000 | 0.631877 | False | 1 |
| glm-5.3 | CNY | 19.377732 | 0.000000 | 19.377732 | False | 1 |

**Cost is incomplete: known amounts are lower bounds; failed requests may have been billed.**

Training samples: 3911/3924 valid; `training/samples.jsonl`.
