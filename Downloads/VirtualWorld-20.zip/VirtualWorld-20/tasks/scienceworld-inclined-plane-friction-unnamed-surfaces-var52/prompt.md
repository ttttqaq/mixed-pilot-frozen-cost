# Task

Task Description:
Your task is to determine which of the two inclined planes (unknown material E, unknown material B) has the most friction. After completing your experiment, focus on the inclined plane with the most friction.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the kitchen. In it, you see: 
	the agent
	a substance called air
	a chair. On the chair is: nothing.
	a counter. On the counter is: a bowl (containing a red apple, a banana, an orange, a potato), a drawer.
	a cupboard. The cupboard door is closed. 
	a freezer. The freezer door is closed. 
	a fridge. The fridge door is closed. 
	a glass jar (containing a substance called sodium chloride)
	a lighter
	a oven, which is turned off. The oven door is closed. 
	a painting
	a sink, which is turned off. In the sink is: nothing.
	a substance called soap
	a stopwatch, which is deactivated. 
	a stove, which is turned off. On the stove is: nothing.
	a table. On the table is: a glass cup (containing nothing).
	a thermometer, currently reading a temperature of 10 degrees celsius
You also see:
	A door to the bathroom (that is closed)
	A door to the hallway (that is closed)
	A door to the outside (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
