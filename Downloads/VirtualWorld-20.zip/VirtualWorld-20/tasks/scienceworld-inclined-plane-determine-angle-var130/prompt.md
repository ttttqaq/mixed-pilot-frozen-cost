# Task

Task Description:
Your task is to determine which of the two inclined planes (C, H) has the shallowest angle. After completing your experiment, focus on the inclined plane with the shallowest angle.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the bathroom. In it, you see: 
	the agent
	a substance called air
	a bathtub, which is turned off. In the bathtub is: nothing.
	a glass cup (containing nothing)
	a painting
	a sink, which is turned off. In the sink is: nothing.
	a toilet. In the toilet is: A drain, which is open, a substance called water.
You also see:
	A door to the kitchen (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
