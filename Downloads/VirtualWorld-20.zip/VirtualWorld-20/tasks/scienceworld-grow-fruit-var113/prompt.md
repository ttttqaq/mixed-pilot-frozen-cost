# Task

Task Description:
Your task is to grow a peach. This will require growing several plants, and them being crosspollinated to produce fruit.  Seeds can be found in the bathroom. To complete the task, focus on the grown peach.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the hallway. In it, you see: 
	the agent
	a substance called air
	a finger painting
You also see:
	A door to the art studio (that is closed)
	A door to the bedroom (that is closed)
	A door to the greenhouse (that is closed)
	A door to the kitchen (that is closed)
	A door to the living room (that is closed)
	A door to the workshop (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
