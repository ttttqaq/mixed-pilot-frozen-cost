# Task

Task Description:
Your task is to find a(n) non-living thing. First, focus on the thing. Then, move it to the green box in the workshop.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the art studio. In it, you see: 
	the agent
	a substance called air
	a large cupboard. The large cupboard door is closed. 
	a table. On the table is: a bowl (containing nothing).
	a wood cup (containing yellow paint)
	a wood cup (containing red paint)
	a wood cup (containing blue paint)
You also see:
	A door to the hallway (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
