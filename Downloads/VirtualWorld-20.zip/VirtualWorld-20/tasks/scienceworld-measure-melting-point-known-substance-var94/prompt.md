# Task

Task Description:
Your task is to measure the melting point of lead, which is located around the kitchen. First, focus on the thermometer. Next, focus on the lead. If the melting point of lead is above 50.0 degrees celsius, focus on the orange box. If the melting point of lead is below 50.0 degrees celsius, focus on the yellow box. The boxes are located around the kitchen.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the greenhouse. In it, you see: 
	the agent
	a substance called air
	a bee hive. The bee hive door is closed. 
	a jug (containing nothing)
	a shovel
	a sink, which is turned off. In the sink is: nothing.
You also see:
	A door to the hallway (that is closed)
	A door to the outside (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
