# Task

Task Description:
Your task is to measure the melting point of gallium, which is located around the kitchen. First, focus on the thermometer. Next, focus on the gallium. If the melting point of gallium is above 200.0 degrees celsius, focus on the yellow box. If the melting point of gallium is below 200.0 degrees celsius, focus on the purple box. The boxes are located around the kitchen.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the hallway. In it, you see: 
	the agent
	a substance called air
	a picture
You also see:
	A door to the art studio (that is closed)
	A door to the bedroom (that is closed)
	A door to the greenhouse (that is closed)
	A door to the kitchen (that is closed)
	A door to the living room (that is closed)
	A door to the workshop (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
