# Task

examine the pillow with the desklamp.

# Workspace

This is a native ALFWorld text simulation. Initial observation:

-= Welcome to TextWorld, ALFRED! =-

You are in the middle of a room. Looking quickly around you, you see a bed 1, a desk 1, a drawer 3, a drawer 2, a drawer 1, a garbagecan 1, a laundryhamper 1, a shelf 2, a shelf 1, and a sidetable 1.

Your task is to: examine the pillow with the desklamp.

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 200.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
