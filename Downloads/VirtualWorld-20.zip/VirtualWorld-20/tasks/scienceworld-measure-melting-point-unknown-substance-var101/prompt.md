# Task

Task Description:
Your task is to measure the melting point of solid unknown substance C, which is located around the kitchen. First, focus on the thermometer. Next, focus on the solid unknown substance C. If the melting point of solid unknown substance C is above 50.0 degrees celsius, focus on the red box. If the melting point of solid unknown substance C is below 50.0 degrees celsius, focus on the green box. The boxes are located around the kitchen.

# Workspace

This is a native ScienceWorld text simulation. Initial observation:

This room is called the bedroom. In it, you see: 
	the agent
	a substance called air
	a bed. On the bed is: a mattress. On the mattress is: a white pillow..
	a book shelf (containing A book (Beowulf) titled Beowulf by Beowulf poet, A book (Pride and Prejudice) titled Pride and Prejudice by Jane Austen, A book (The Foundations of the Origin of Species) titled The Foundations of the Origin of Species by Charles Darwin)
	a closet. The closet door is closed. 
	a picture
	a table. On the table is: nothing.
You also see:
	A door to the hallway (that is closed)

Use `python vw.py start`, `python vw.py info`, `python vw.py valid`,
`python vw.py step "<one action>"`, and `python vw.py stop` from the workspace.
With mixed-pilot `infer.py`, issue one command in a ```text``` code block instead;
the harness owns the environment and supplies observations after each command.

# Deliverables

Complete the objective in the environment. The runtime records `score.json`.
Scores use a 0–100 scale; full success is 100. Self-reported files do not determine success.

# Constraints

- Maximum native actions: 500.
- A terminal episode can be unsuccessful. Stop after native success or termination.
- Keep file operations within the workspace. Reference files are grader-only.
