# VirtualWorld-20

从 `/Users/liangjianfeng/Data/Router/VirtualWorld-1000` 的候选池中均匀、无放回随机抽取 20 条。
抽样前排除 `/Users/liangjianfeng/Data/Router/VirtualWorld-100` 的 100 条任务，按 task ID 和原生实例身份双重去重。
父数据集共 1000 条，排除后候选池 900 条；与排除数据集重合为 0。
随机种子 42，抽样前按 task ID 排序。训练集 0 条，测试集 20 条。

ScienceWorld 7 条；ALFWorld 13 条。
原 train 17 条，原 test 3 条。
manifest 的 router_split 统一为 test；parent_router_split 和原始 source.split 保留来源。
任务 workspace、prompt、rubrics 和 reference 完整复制；reference 仍仅供评测使用。
原生成功重放记录继承自父数据集，本次检查文件完整性与 harness 加载，未重新运行环境。

本数据集用于测试，全部任务的 router_split=test；父数据集的 train/test 来源仅作为 provenance 保留。

运行示例（在当前 mixed-pilot 项目目录执行）：

```bash
outputs/virtualworld-venv/bin/python scripts/infer.py \
  --dataset /Users/liangjianfeng/Data/Router/VirtualWorld-20 --split test \
  --mode single-model --models deepseek-flash --step-limit 500 \
  --output-dir run/virtualworld-20-dry-run --dry-run
```

完整选样记录见 selection.json，文件清单见 SHA256SUMS，验证见 validation_report.json。
