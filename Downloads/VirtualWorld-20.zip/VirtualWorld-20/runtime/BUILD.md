TextWorld 1.7.0 from the PyPI source distribution. Only setup.py _pre_install was replaced with pass.
The Inform7 compiler download/mount is irrelevant to ALFWorld PDDL and was skipped.
All textworld/ Python sources are unchanged. Wheel platform: macOS arm64, Python 3.12.
Install the provided wheel plus runtime/requirements.txt in a compatible environment.
fast-downward-textworld 20.6.4 was built from the unmodified PyPI source.
Java is required by ScienceWorld. No pretrained model, detector or AI2-THOR renderer is needed.
